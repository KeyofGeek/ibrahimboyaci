export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: 'AIzaSyDFEEGLS4LfSN1sZPftutApHorOhusv1uk',
    authDomain: 'uyg04-25b15.firebaseapp.com',
    databaseURL: 'https://uyg04-25b15-default-rtdb.firebaseio.com',
    projectId: 'uyg04-25b15',
    storageBucket: 'uyg04-25b15.appspot.com',
    messagingSenderId: '323206389701',
    appId: '1:323206389701:web:90945b1a2642ace1ea35ac',
    measurementId: 'G-QHQFRX7T0X',
  },
};
