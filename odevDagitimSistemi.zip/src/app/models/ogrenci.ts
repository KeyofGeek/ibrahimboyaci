export class Ogrenci {
  key: string;
  Id?: number;
  Adsoyad?: string;
}
