export class Odev {
  key: string;
  Id?: number;
  Odev?: string;
}
