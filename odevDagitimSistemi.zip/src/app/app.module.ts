import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AngularFireModule } from '@angular/fire/compat';
import { AngularFireDatabaseModule } from '@angular/fire/compat/database';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AnasayfaComponent } from './components/anasayfa/anasayfa.component';
import { HakkimdaComponent } from './components/hakkimda/hakkimda.component';
import { DagitComponent } from './components/dagit/dagit.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { environment } from 'src/environments/environment';
import { OgrEkleComponent } from './components/ogr-ekle/ogr-ekle.component';
import { OdvEkleComponent } from './components/odv-ekle/odv-ekle.component';
import { DagitildiComponent } from './components/dagitildi/dagitildi.component';

@NgModule({
  declarations: [
    AppComponent,
    AnasayfaComponent,
    HakkimdaComponent,
    DagitComponent,
    OgrEkleComponent,
    OdvEkleComponent,
    DagitildiComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireDatabaseModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
