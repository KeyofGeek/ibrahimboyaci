import { Injectable } from '@angular/core';

import {
  AngularFireDatabase,
  AngularFireList,
} from '@angular/fire/compat/database';
import { Observable } from 'rxjs';
import { Odev } from '../models/odev';

@Injectable({
  providedIn: 'root',
})
export class FbodevlerService {
  private dbOdev = '/Odevler';

  odevRef: AngularFireList<Odev> = null;
  constructor(public db: AngularFireDatabase) {
    this.odevRef = db.list(this.dbOdev);
  }

  fbOdevListele() {
    return this.odevRef;
  }

  fbOdevEkle(k: Odev) {
    return this.odevRef.push(k);
  }

  fbOdevDuzenle(k: Odev) {
    return this.odevRef.update(k.key, k);
  }

  fbOdevSil(key: string) {
    return this.odevRef.remove(key);
  }
}
