import { TestBed } from '@angular/core/testing';

import { FbogrencilerService } from './fbogrenciler.service';

describe('FbogrencilerService', () => {
  let service: FbogrencilerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FbogrencilerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
