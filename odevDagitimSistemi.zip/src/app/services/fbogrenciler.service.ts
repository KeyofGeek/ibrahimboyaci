import { Injectable } from '@angular/core';
import {
  AngularFireDatabase,
  AngularFireList,
} from '@angular/fire/compat/database';
import { Ogrenci } from '../models/ogrenci';

@Injectable({
  providedIn: 'root',
})
export class FbogrencilerService {
  private dbOgrenci = '/Ogrenciler';

  ogrenciRef: AngularFireList<Ogrenci> = null;
  constructor(public db: AngularFireDatabase) {
    this.ogrenciRef = db.list(this.dbOgrenci);
  }

  fbOgrenciListele() {
    return this.ogrenciRef;
  }

  fbOgrenciEkle(k: Ogrenci) {
    return this.ogrenciRef.push(k);
  }

  fbOgrenciDuzenle(k: Ogrenci) {
    return this.ogrenciRef.update(k.key, k);
  }

  fbOgrenciSil(key: string) {
    return this.ogrenciRef.remove(key);
  }
}
