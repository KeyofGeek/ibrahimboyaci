import { TestBed } from '@angular/core/testing';

import { FbodevlerService } from './fbodevler.service';

describe('FbodevlerService', () => {
  let service: FbodevlerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FbodevlerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
