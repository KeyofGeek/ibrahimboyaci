import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hakkimda',
  templateUrl: './hakkimda.component.html',
  styleUrls: ['./hakkimda.component.css']
})
export class HakkimdaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
