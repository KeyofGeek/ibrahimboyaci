import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DagitildiComponent } from './dagitildi.component';

describe('DagitildiComponent', () => {
  let component: DagitildiComponent;
  let fixture: ComponentFixture<DagitildiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DagitildiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DagitildiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
