import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { Odev } from 'src/app/models/odev';
import { Ogrenci } from 'src/app/models/ogrenci';
import { FbodevlerService } from 'src/app/services/fbodevler.service';
import { FbogrencilerService } from 'src/app/services/fbogrenciler.service';

@Component({
  selector: 'app-dagitildi',
  templateUrl: './dagitildi.component.html',
  styleUrls: ['./dagitildi.component.css'],
})
export class DagitildiComponent implements OnInit {
  ogrenciListesi: Ogrenci[];
  odevListesi: Odev[];
  ogrenciler: any;
  odevler: any;

  constructor(
    public fbOgrencilerServis: FbogrencilerService,
    public fbOdevlerServis: FbodevlerService
  ) {}

  ngOnInit(): void {
    this.FbOgrenciListele();
    this.FbOdevListele();
  }

  FbOgrenciListele() {
    this.fbOgrencilerServis
      .fbOgrenciListele()
      .snapshotChanges()
      .pipe(
        map((changes: any[]) =>
          changes.map((c) => ({ key: c.payload.key, ...c.payload.val() }))
        )
      )
      .subscribe((data) => {
        this.ogrenciler = data;
      });
  }

  FbOdevListele() {
    this.fbOdevlerServis
      .fbOdevListele()
      .snapshotChanges()
      .pipe(
        map((changes: any[]) =>
          changes.map((c) => ({ key: c.payload.key, ...c.payload.val() }))
        )
      )
      .subscribe((data) => {
        this.odevler = data;
      });
  }
}
