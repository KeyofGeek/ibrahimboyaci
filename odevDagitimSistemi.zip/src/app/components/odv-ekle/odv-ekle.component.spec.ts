import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OdvEkleComponent } from './odv-ekle.component';

describe('OdvEkleComponent', () => {
  let component: OdvEkleComponent;
  let fixture: ComponentFixture<OdvEkleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OdvEkleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OdvEkleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
