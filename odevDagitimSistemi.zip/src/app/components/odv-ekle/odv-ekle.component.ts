import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Odev } from 'src/app/models/odev';
import { FbodevlerService } from 'src/app/services/fbodevler.service';

@Component({
  selector: 'app-odv-ekle',
  templateUrl: './odv-ekle.component.html',
  styleUrls: ['./odv-ekle.component.css'],
})
export class OdvEkleComponent implements OnInit {
  odevEkle: Odev = new Odev();

  constructor(
    public fbOdevlerServis: FbodevlerService,
    public router: Router
  ) {}

  ngOnInit(): void {}

  FbOgrenciEkle() {
    this.fbOdevlerServis.fbOdevEkle(this.odevEkle).then(() => {
      this.router.navigate(['/dagit']);
    });
  }
}
