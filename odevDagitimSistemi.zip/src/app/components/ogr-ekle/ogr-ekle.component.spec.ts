import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OgrEkleComponent } from './ogr-ekle.component';

describe('OgrEkleComponent', () => {
  let component: OgrEkleComponent;
  let fixture: ComponentFixture<OgrEkleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OgrEkleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OgrEkleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
