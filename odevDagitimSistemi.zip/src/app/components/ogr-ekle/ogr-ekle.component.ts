import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ogrenci } from 'src/app/models/ogrenci';
import { FbogrencilerService } from 'src/app/services/fbogrenciler.service';

@Component({
  selector: 'app-ogr-ekle',
  templateUrl: './ogr-ekle.component.html',
  styleUrls: ['./ogr-ekle.component.css'],
})
export class OgrEkleComponent implements OnInit {
  ogrenciEkle: Ogrenci = new Ogrenci();

  constructor(
    public fbOgrencilerServis: FbogrencilerService,
    public router: Router
  ) {}

  ngOnInit(): void {}

  FbOgrenciEkle() {
    this.fbOgrencilerServis.fbOgrenciEkle(this.ogrenciEkle).then(() => {
      this.router.navigate(['/dagit']);
    });
  }
}
