import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Odev } from 'src/app/models/odev';
import { Ogrenci } from 'src/app/models/ogrenci';
import { FbodevlerService } from 'src/app/services/fbodevler.service';
import { FbogrencilerService } from 'src/app/services/fbogrenciler.service';

@Component({
  selector: 'app-dagit',
  templateUrl: './dagit.component.html',
  styleUrls: ['./dagit.component.css'],
})
export class DagitComponent implements OnInit {
  secOgr: Ogrenci = new Ogrenci();
  secOdv: Odev = new Odev();
  ogrenciListesi?: Ogrenci[];
  odevListesi?: Odev[];
  ogrenciler: any;
  odevler: any;
  ogrduz: boolean = false;
  odvduz: boolean = false;

  constructor(
    public fbOgrencilerServis: FbogrencilerService,
    public fbOdevlerServis: FbodevlerService,
    public router: Router
  ) {}

  ngOnInit(): void {
    this.FbOgrenciListele();
    this.FbOdevListele();
  }

  FbOgrenciListele() {
    this.fbOgrencilerServis
      .fbOgrenciListele()
      .snapshotChanges()
      .pipe(
        map((changes: any[]) =>
          changes.map((c) => ({ key: c.payload.key, ...c.payload.val() }))
        )
      )
      .subscribe((data) => {
        this.ogrenciler = data;
      });
  }

  FbOdevListele() {
    this.fbOdevlerServis
      .fbOdevListele()
      .snapshotChanges()
      .pipe(
        map((changes: any[]) =>
          changes.map((c) => ({ key: c.payload.key, ...c.payload.val() }))
        )
      )
      .subscribe((data) => {
        this.odevler = data;
      });
  }

  FbOgrenciSil(k: Ogrenci) {
    this.fbOgrencilerServis.fbOgrenciSil(k.key).then(() => {});
  }

  FbOdevciSil(k: Odev) {
    this.fbOdevlerServis.fbOdevSil(k.key).then(() => {});
  }

  OgrSec(o: Ogrenci) {
    Object.assign(this.secOgr, o);
  }

  OgrDuzenle() {
    this.fbOgrencilerServis.fbOgrenciDuzenle(this.secOgr).then(() => {
      this.secOgr = new Ogrenci();
    });
  }

  OdvSec(o: Odev) {
    Object.assign(this.secOdv, o);
  }

  OdvDuzenle() {
    this.fbOdevlerServis.fbOdevDuzenle(this.secOdv).then(() => {
      this.secOdv = new Odev();
    });
  }

  // byindex(i: Odev) {
  //   var index = this.odevListesi?.indexOf(i);
  //   // console.log(index);
  //   this.router.navigate(['/duzenle1', index]);
  // }
}
