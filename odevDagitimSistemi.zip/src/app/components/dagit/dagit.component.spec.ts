import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DagitComponent } from './dagit.component';

describe('DagitComponent', () => {
  let component: DagitComponent;
  let fixture: ComponentFixture<DagitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DagitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DagitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
