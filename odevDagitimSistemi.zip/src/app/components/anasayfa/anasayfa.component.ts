import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-anasayfa',
  templateUrl: './anasayfa.component.html',
  styleUrls: ['./anasayfa.component.css']
})
export class AnasayfaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
