import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AnasayfaComponent } from './components/anasayfa/anasayfa.component';
import { DagitComponent } from './components/dagit/dagit.component';
import { DagitildiComponent } from './components/dagitildi/dagitildi.component';

import { HakkimdaComponent } from './components/hakkimda/hakkimda.component';
import { OdvEkleComponent } from './components/odv-ekle/odv-ekle.component';
import { OgrEkleComponent } from './components/ogr-ekle/ogr-ekle.component';

const routes: Routes = [
  { path: '', component: AnasayfaComponent },
  { path: 'hakkimda', component: HakkimdaComponent },
  { path: 'dagit', component: DagitComponent },
  { path: 'ogrEkle', component: OgrEkleComponent },
  { path: 'odvEkle', component: OdvEkleComponent },
  { path: 'dagitildi', component: DagitildiComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
